import { pgTable, text, bigint, timestamp, primaryKey } from "drizzle-orm/pg-core";

export const notificationSubscriptionsTable = pgTable(
  "notification_subscriptions",
  {
    chatId: bigint("chat_id", { mode: "number" }).notNull(),
    leagueCode: text("league_code").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [primaryKey({ columns: [t.chatId, t.leagueCode] })],
);

export type NotificationSubscription = typeof notificationSubscriptionsTable.$inferSelect;
