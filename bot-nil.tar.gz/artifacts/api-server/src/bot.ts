import { Markup, Telegraf } from "telegraf";
import { db, notificationSubscriptionsTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { logger } from "./lib/logger";

type Fixture = {
  fixture: { id: number; date: string; status?: { elapsed?: number | null; short?: string } };
  league?: { id: number; name?: string };
  teams: { home: { name: string }; away: { name: string } };
  goals?: { home: number | null; away: number | null };
};

type StatItem = { type: string; value: number | string | null };
type StatsResponse = {
  response: Array<{ team: { name: string }; statistics: StatItem[] }>;
};

type StandingRow = {
  rank: number;
  team: { name: string };
  points: number;
  all: { played: number };
};

type StandingsResponse = {
  response: Array<{
    league: { standings: StandingRow[][] };
  }>;
};

type League = { code: string; name: string; id: number; season: number };

const TZ = "America/Sao_Paulo";

const LEAGUES: League[] = [
  { code: "brasileirao", name: "Brasileirão Série A", id: 71, season: 2026 },
  { code: "serieb", name: "Brasileirão Série B", id: 72, season: 2026 },
  { code: "premier", name: "Premier League", id: 39, season: 2025 },
  { code: "championship", name: "Championship", id: 40, season: 2025 },
  { code: "laliga", name: "La Liga", id: 140, season: 2025 },
  { code: "laliga2", name: "La Liga 2", id: 141, season: 2025 },
  { code: "seriea", name: "Serie A (Itália)", id: 135, season: 2025 },
  { code: "serieb_ita", name: "Serie B (Itália)", id: 136, season: 2025 },
  { code: "bundesliga", name: "Bundesliga", id: 78, season: 2025 },
  { code: "bundesliga2", name: "Bundesliga 2", id: 79, season: 2025 },
  { code: "ligue1", name: "Ligue 1", id: 61, season: 2025 },
  { code: "ligue2", name: "Ligue 2", id: 62, season: 2025 },
  { code: "libertadores", name: "Libertadores", id: 13, season: 2026 },
  { code: "sulamericana", name: "Sul-Americana", id: 11, season: 2026 },
];

const LEAGUE_BY_CODE = new Map(LEAGUES.map((l) => [l.code, l]));

function todayInSaoPaulo(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

function formatTime(iso: string): string {
  return new Intl.DateTimeFormat("pt-BR", {
    timeZone: TZ,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(new Date(iso));
}

async function apiGet<T>(apiKey: string, path: string, params: Record<string, string>): Promise<T> {
  const url = new URL(`https://v3.football.api-sports.io/${path}`);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  const res = await fetch(url, { headers: { "x-apisports-key": apiKey } });
  if (!res.ok) throw new Error(`API-Football responded ${res.status}`);
  return (await res.json()) as T;
}

async function fetchTodayFixtures(apiKey: string, league: League): Promise<Fixture[]> {
  const data = await apiGet<{ response: Fixture[] }>(apiKey, "fixtures", {
    league: String(league.id),
    season: String(league.season),
    date: todayInSaoPaulo(),
    timezone: TZ,
  });
  return data.response ?? [];
}

async function fetchLiveFixtures(apiKey: string, league?: League): Promise<Fixture[]> {
  const params: Record<string, string> = { live: "all", timezone: TZ };
  if (league) params["league"] = String(league.id);
  const data = await apiGet<{ response: Fixture[] }>(apiKey, "fixtures", params);
  return data.response ?? [];
}

async function fetchFixtureStats(apiKey: string, fixtureId: number): Promise<StatsResponse> {
  return apiGet<StatsResponse>(apiKey, "fixtures/statistics", {
    fixture: String(fixtureId),
  });
}

type FixtureWithIds = Fixture & {
  teams: { home: { id: number; name: string }; away: { id: number; name: string } };
};

async function fetchNextFixture(apiKey: string, league: League): Promise<FixtureWithIds | null> {
  const data = await apiGet<{ response: FixtureWithIds[] }>(apiKey, "fixtures", {
    league: String(league.id),
    season: String(league.season),
    next: "1",
    timezone: TZ,
  });
  return data.response?.[0] ?? null;
}

async function fetchH2H(
  apiKey: string,
  homeId: number,
  awayId: number,
): Promise<FixtureWithIds[]> {
  const data = await apiGet<{ response: FixtureWithIds[] }>(apiKey, "fixtures/headtohead", {
    h2h: `${homeId}-${awayId}`,
    last: "5",
    timezone: TZ,
  });
  return data.response ?? [];
}

async function fetchStandings(apiKey: string, league: League): Promise<StandingRow[]> {
  const data = await apiGet<StandingsResponse>(apiKey, "standings", {
    league: String(league.id),
    season: String(league.season),
  });
  return data.response?.[0]?.league?.standings?.[0] ?? [];
}

function leaguesMenu() {
  const rows = [];
  for (let i = 0; i < LEAGUES.length; i += 2) {
    const row = LEAGUES.slice(i, i + 2).map((l) =>
      Markup.button.callback(l.name, `liga:${l.code}`),
    );
    rows.push(row);
  }
  return Markup.inlineKeyboard(rows);
}

function unknownLeagueMessage(): string {
  const codes = LEAGUES.map((l) => l.code).join(", ");
  return `Liga não reconhecida. Códigos válidos:\n${codes}`;
}

export function startBot(): Telegraf | null {
  const token = process.env["TELEGRAM_BOT_TOKEN"];
  const apiKey = process.env["API_FOOTBALL_KEY"];

  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN is not set; Telegram bot will not start.");
    return null;
  }

  const bot = new Telegraf(token);

  bot.start((ctx) => ctx.reply("Bot do Nil Online ⚽ Pronto pra buscar os jogos"));

  bot.command("ligas", async (ctx) => {
    await ctx.reply("Escolha uma liga:", leaguesMenu());
  });

  const sendFixtures = async (
    reply: (text: string) => Promise<unknown>,
    league: League,
  ) => {
    if (!apiKey) {
      await reply("API_FOOTBALL_KEY não configurada.");
      return;
    }
    try {
      const fixtures = await fetchTodayFixtures(apiKey, league);
      if (fixtures.length === 0) {
        await reply(`Nenhum jogo de ${league.name} hoje.`);
        return;
      }
      const lines = fixtures
        .map(
          (f) =>
            `${formatTime(f.fixture.date)} - ${f.teams.home.name} x ${f.teams.away.name}`,
        )
        .join("\n");
      await reply(`${league.name} - Jogos de hoje\n${lines}`);
    } catch (err) {
      logger.error({ err, league: league.code }, "Failed to fetch fixtures");
      await reply("Erro ao buscar os jogos. Tente novamente.");
    }
  };

  const sendStandings = async (
    reply: (text: string) => Promise<unknown>,
    league: League,
  ) => {
    if (!apiKey) {
      await reply("API_FOOTBALL_KEY não configurada.");
      return;
    }
    try {
      const standings = await fetchStandings(apiKey, league);
      if (standings.length === 0) {
        await reply("Tabela indisponível no momento.");
        return;
      }
      const lines = standings
        .slice(0, 6)
        .map((s) => `${s.rank}. ${s.team.name} - ${s.points} pts (${s.all.played}j)`)
        .join("\n");
      await reply(`${league.name} - Top 6\n${lines}`);
    } catch (err) {
      logger.error({ err, league: league.code }, "Failed to fetch standings");
      await reply("Erro ao buscar a tabela. Tente novamente.");
    }
  };

  bot.command("liga", async (ctx) => {
    const arg = ctx.message.text.split(/\s+/)[1]?.toLowerCase();
    if (!arg) {
      await ctx.reply("Uso: /liga [codigo]. Veja /ligas para o menu.");
      return;
    }
    const league = LEAGUE_BY_CODE.get(arg);
    if (!league) {
      await ctx.reply(unknownLeagueMessage());
      return;
    }
    await sendFixtures((t) => ctx.reply(t), league);
  });

  bot.command("tabela", async (ctx) => {
    const arg = ctx.message.text.split(/\s+/)[1]?.toLowerCase();
    if (!arg) {
      await ctx.reply("Uso: /tabela [codigo]. Veja /ligas para o menu.");
      return;
    }
    const league = LEAGUE_BY_CODE.get(arg);
    if (!league) {
      await ctx.reply(unknownLeagueMessage());
      return;
    }
    await sendStandings((t) => ctx.reply(t), league);
  });

  const formatLiveLine = (f: Fixture) => {
    const home = f.teams.home.name;
    const away = f.teams.away.name;
    const gh = f.goals?.home ?? 0;
    const ga = f.goals?.away ?? 0;
    const elapsed = f.fixture.status?.elapsed;
    const min = elapsed != null ? `${elapsed}'` : (f.fixture.status?.short ?? "AO VIVO");
    return `${min} | ${home} ${gh} x ${ga} ${away}`;
  };

  bot.command("aovivo", async (ctx) => {
    if (!apiKey) {
      await ctx.reply("API_FOOTBALL_KEY não configurada.");
      return;
    }
    const arg = ctx.message.text.split(/\s+/)[1]?.toLowerCase();
    if (!arg) {
      await ctx.reply("Uso: /aovivo [codigo]. Veja /ligas para o menu.");
      return;
    }
    const league = LEAGUE_BY_CODE.get(arg);
    if (!league) {
      await ctx.reply(unknownLeagueMessage());
      return;
    }
    try {
      const live = await fetchLiveFixtures(apiKey, league);
      if (live.length === 0) {
        await ctx.reply(`Nenhum jogo ao vivo de ${league.name} agora.`);
        return;
      }
      const lines = live.map(formatLiveLine).join("\n");
      await ctx.reply(`${league.name} - AO VIVO\n${lines}`);
    } catch (err) {
      logger.error({ err, league: league.code }, "Failed to fetch live fixtures");
      await ctx.reply("Erro ao buscar jogos ao vivo. Tente novamente.");
    }
  });

  bot.command("stats", async (ctx) => {
    if (!apiKey) {
      await ctx.reply("API_FOOTBALL_KEY não configurada.");
      return;
    }
    try {
      const live = await fetchLiveFixtures(apiKey);
      if (live.length === 0) {
        await ctx.reply("Nenhum jogo ao vivo agora.");
        return;
      }
      for (const f of live.slice(0, 10)) {
        await ctx.reply(
          formatLiveLine(f),
          Markup.inlineKeyboard([
            Markup.button.callback("Ver Estatísticas", `stats:${f.fixture.id}`),
          ]),
        );
      }
    } catch (err) {
      logger.error({ err }, "Failed to fetch live fixtures for stats");
      await ctx.reply("Erro ao buscar jogos ao vivo. Tente novamente.");
    }
  });

  const STAT_LABELS: Record<string, string> = {
    "Shots on Goal": "Chutes no gol",
    "Total Shots": "Chutes totais",
    "Ball Possession": "Posse de bola",
    "Corner Kicks": "Escanteios",
    "Yellow Cards": "Cartões amarelos",
    "Red Cards": "Cartões vermelhos",
    "Fouls": "Faltas",
  };
  const STAT_ORDER = [
    "Shots on Goal",
    "Total Shots",
    "Ball Possession",
    "Corner Kicks",
    "Yellow Cards",
    "Red Cards",
    "Fouls",
  ];

  bot.action(/^stats:(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!apiKey) {
      await ctx.reply("API_FOOTBALL_KEY não configurada.");
      return;
    }
    const fixtureId = Number(ctx.match[1]);
    try {
      const data = await fetchFixtureStats(apiKey, fixtureId);
      if (!data.response || data.response.length < 2) {
        await ctx.reply("Estatísticas indisponíveis para esse jogo.");
        return;
      }
      const [home, away] = data.response;
      const valFor = (team: typeof home, type: string) => {
        const v = team.statistics.find((s) => s.type === type)?.value;
        return v == null || v === "" ? "0" : String(v);
      };
      const lines = [`${home.team.name} x ${away.team.name}`];
      for (const type of STAT_ORDER) {
        const label = STAT_LABELS[type] ?? type;
        lines.push(`${label}: ${valFor(home, type)} - ${valFor(away, type)}`);
      }
      await ctx.reply(lines.join("\n"));
    } catch (err) {
      logger.error({ err, fixtureId }, "Failed to fetch fixture stats");
      await ctx.reply("Erro ao buscar estatísticas.");
    }
  });

  const fixtureStates = new Map<number, string>();
  const LIVE_STATUSES = new Set(["1H", "HT", "2H", "ET", "BT", "P", "LIVE"]);
  const DONE_STATUSES = new Set(["FT", "AET", "PEN"]);

  bot.command("minhas", async (ctx) => {
    const chatId = ctx.chat.id;
    try {
      const rows = await db
        .select()
        .from(notificationSubscriptionsTable)
        .where(eq(notificationSubscriptionsTable.chatId, chatId));
      if (rows.length === 0) {
        await ctx.reply("Você não tem nenhuma notificação ativa. Use /notificar [codigo].");
        return;
      }
      const lines = rows.map((r) => {
        const league = LEAGUE_BY_CODE.get(r.leagueCode);
        return `• ${league?.name ?? r.leagueCode} (${r.leagueCode})`;
      });
      await ctx.reply(`Suas notificações ativas:\n${lines.join("\n")}`);
    } catch (err) {
      logger.error({ err, chatId }, "Failed to list subscriptions");
      await ctx.reply("Erro ao buscar suas inscrições. Tente novamente.");
    }
  });

  bot.command("notificar", async (ctx) => {
    const arg = ctx.message.text.split(/\s+/)[1]?.toLowerCase();
    if (!arg) {
      await ctx.reply("Uso: /notificar [codigo]. Veja /ligas para o menu.");
      return;
    }
    const league = LEAGUE_BY_CODE.get(arg);
    if (!league) {
      await ctx.reply(unknownLeagueMessage());
      return;
    }
    const chatId = ctx.chat.id;
    try {
      const existing = await db
        .select()
        .from(notificationSubscriptionsTable)
        .where(
          and(
            eq(notificationSubscriptionsTable.chatId, chatId),
            eq(notificationSubscriptionsTable.leagueCode, league.code),
          ),
        );
      if (existing.length > 0) {
        await db
          .delete(notificationSubscriptionsTable)
          .where(
            and(
              eq(notificationSubscriptionsTable.chatId, chatId),
              eq(notificationSubscriptionsTable.leagueCode, league.code),
            ),
          );
        await ctx.reply(`Notificações de ${league.name} desativadas.`);
      } else {
        await db
          .insert(notificationSubscriptionsTable)
          .values({ chatId, leagueCode: league.code });
        await ctx.reply(
          `Notificações de ${league.name} ativadas. Você receberá avisos quando os jogos começarem e terminarem.`,
        );
      }
    } catch (err) {
      logger.error({ err, chatId, league: league.code }, "Failed to toggle subscription");
      await ctx.reply("Erro ao salvar inscrição. Tente novamente.");
    }
  });

  const pollNotifications = async () => {
    if (!apiKey) return;
    let subs;
    try {
      subs = await db.select().from(notificationSubscriptionsTable);
    } catch (err) {
      logger.error({ err }, "Failed to load subscriptions");
      return;
    }
    if (subs.length === 0) return;

    const byLeague = new Map<string, number[]>();
    for (const s of subs) {
      const list = byLeague.get(s.leagueCode) ?? [];
      list.push(s.chatId);
      byLeague.set(s.leagueCode, list);
    }

    for (const [code, chatIds] of byLeague) {
      const league = LEAGUE_BY_CODE.get(code);
      if (!league) continue;
      try {
        const fixtures = await fetchTodayFixtures(apiKey, league);
        for (const f of fixtures) {
          const status = f.fixture.status?.short ?? "NS";
          const prev = fixtureStates.get(f.fixture.id);
          fixtureStates.set(f.fixture.id, status);
          if (prev === undefined) continue;
          if (prev === status) continue;

          const home = f.teams.home.name;
          const away = f.teams.away.name;
          let msg: string | null = null;

          if (!LIVE_STATUSES.has(prev) && LIVE_STATUSES.has(status)) {
            msg = `⚽ Começou: ${home} x ${away} (${league.name})`;
          } else if (!DONE_STATUSES.has(prev) && DONE_STATUSES.has(status)) {
            const gh = f.goals?.home ?? 0;
            const ga = f.goals?.away ?? 0;
            msg = `🏁 Terminou: ${home} ${gh} x ${ga} ${away} (${league.name})`;
          }

          if (msg) {
            for (const chatId of chatIds) {
              try {
                await bot.telegram.sendMessage(chatId, msg);
              } catch (err) {
                logger.error({ err, chatId }, "Failed to send notification");
              }
            }
          }
        }
      } catch (err) {
        logger.error({ err, league: code }, "Notification poll failed");
      }
    }
  };

  const notifyInterval = setInterval(() => {
    void pollNotifications();
  }, 60_000);

  process.once("SIGINT", () => clearInterval(notifyInterval));
  process.once("SIGTERM", () => clearInterval(notifyInterval));

  bot.command("h2h", async (ctx) => {
    if (!apiKey) {
      await ctx.reply("API_FOOTBALL_KEY não configurada.");
      return;
    }
    const arg = ctx.message.text.split(/\s+/)[1]?.toLowerCase();
    if (!arg) {
      await ctx.reply("Uso: /h2h [codigo]. Veja /ligas para o menu.");
      return;
    }
    const league = LEAGUE_BY_CODE.get(arg);
    if (!league) {
      await ctx.reply(unknownLeagueMessage());
      return;
    }
    try {
      const next = await fetchNextFixture(apiKey, league);
      if (!next) {
        await ctx.reply(`Nenhum próximo jogo de ${league.name}.`);
        return;
      }
      const home = next.teams.home;
      const away = next.teams.away;
      const h2h = await fetchH2H(apiKey, home.id, away.id);
      const dateStr = new Intl.DateTimeFormat("pt-BR", {
        timeZone: TZ,
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      }).format(new Date(next.fixture.date));
      const lines = [
        `${home.name} x ${away.name} - Próximo jogo`,
        `${dateStr}`,
        "",
        "Últimos 5 confrontos:",
      ];
      if (h2h.length === 0) {
        lines.push("Sem histórico recente.");
      } else {
        for (const f of h2h) {
          const gh = f.goals?.home ?? 0;
          const ga = f.goals?.away ?? 0;
          lines.push(`${f.teams.home.name} ${gh}x${ga} ${f.teams.away.name}`);
        }
      }
      await ctx.reply(lines.join("\n"));
    } catch (err) {
      logger.error({ err, league: league.code }, "Failed to fetch H2H");
      await ctx.reply("Erro ao buscar confrontos. Tente novamente.");
    }
  });

  bot.action(/^liga:(.+)$/, async (ctx) => {
    const code = ctx.match[1];
    const league = LEAGUE_BY_CODE.get(code);
    await ctx.answerCbQuery();
    if (!league) {
      await ctx.reply(unknownLeagueMessage());
      return;
    }
    await sendFixtures((t) => ctx.reply(t), league);
  });

  bot
    .launch()
    .then(() => {
      logger.info("Telegram bot started (long polling)");
    })
    .catch((err) => {
      logger.error({ err }, "Failed to start Telegram bot");
    });

  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));

  return bot;
}
